<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Users (replace Laravel default)
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username')->unique();
            $table->string('name');
            $table->string('password');
            $table->enum('role', ['admin', 'seller'])->default('seller');
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->unsignedInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('sku')->unique()->nullable();
            $table->decimal('price', 10, 2);
            $table->boolean('track_stock')->default(true);
            $table->integer('stock_qty')->default(0); // atomic current stock
            $table->string('image_path')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('receipt_counters', function (Blueprint $table) {
            $table->id();
            $table->unsignedSmallInteger('receipt_year');
            $table->unsignedInteger('seq_no')->default(0);
            $table->unique(['receipt_year']);
        });

        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('client_uuid', 36)->unique(); // prevent duplicate
            $table->unsignedSmallInteger('receipt_year');
            $table->unsignedInteger('seq_no');
            $table->string('receipt_no_short', 20); // MP690001
            $table->string('receipt_no_long', 20);  // MP20260001
            $table->foreignId('user_id')->constrained();
            $table->string('terminal_name')->nullable();
            $table->enum('payment_method', ['cash', 'transfer', 'credit']);
            $table->decimal('total', 10, 2);
            $table->decimal('cash_received', 10, 2)->nullable();
            $table->decimal('change_amount', 10, 2)->nullable();
            $table->enum('status', ['normal', 'void'])->default('normal');
            $table->foreignId('voided_by')->nullable()->constrained('users');
            $table->timestamp('voided_at')->nullable();
            $table->string('void_reason')->nullable();
            $table->timestamps();
            $table->unique(['receipt_year', 'seq_no']);
            $table->index(['created_at', 'status']);
        });

        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->nullable()->constrained();
            $table->string('product_name');
            $table->decimal('unit_price', 10, 2);
            $table->unsignedInteger('qty');
            $table->decimal('line_total', 10, 2);
            $table->boolean('track_stock')->default(true);
        });

        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained();
            $table->enum('type', ['receive', 'sale', 'void', 'adjust']);
            $table->integer('qty'); // positive or negative
            $table->integer('stock_after');
            $table->foreignId('order_id')->nullable()->constrained();
            $table->foreignId('user_id')->nullable()->constrained();
            $table->string('note')->nullable();
            $table->date('movement_date');
            $table->timestamps();
            $table->index(['product_id', 'movement_date']);
        });

        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->timestamps();
        });

        Schema::create('activity_logs', function (Blueprint $table) {
            $table->id();
            $table->string('action_code')->index();
            $table->text('message_th');
            $table->enum('level', ['info', 'warning', 'error'])->default('info');
            $table->foreignId('user_id')->nullable()->constrained();
            $table->string('terminal_name')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->json('properties')->nullable();
            $table->timestamps();
            $table->index('created_at');
        });

        Schema::create('cash_counts', function (Blueprint $table) {
            $table->id();
            $table->date('count_date');
            $table->foreignId('user_id')->constrained();
            $table->json('denominations'); // {1000: 2, 500: 1, ...}
            $table->decimal('total_counted', 10, 2);
            $table->decimal('system_cash', 10, 2);
            $table->decimal('difference', 10, 2);
            $table->timestamps();
        });

        // Default settings for fictional company
        // (inserted via seeder or install command)
    }

    public function down(): void
    {
        Schema::dropIfExists('cash_counts');
        Schema::dropIfExists('activity_logs');
        Schema::dropIfExists('settings');
        Schema::dropIfExists('stock_movements');
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('receipt_counters');
        Schema::dropIfExists('products');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('users');
    }
};
