<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Default categories
        Category::insert([
            ['name' => 'ข้าว', 'sort_order' => 1, 'is_active' => true, 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'เบเกอรี่', 'sort_order' => 2, 'is_active' => true, 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'เครื่องดื่ม', 'sort_order' => 3, 'is_active' => true, 'created_at' => now(), 'updated_at' => now()],
        ]);

        // Fictional company defaults
        Setting::set('company_name', 'บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด');
        Setting::set('company_address', '88/9 ถนนสุขุมวิท ซอย 39 แขวงคลองตันเหนือ เขตวัฒนา กรุงเทพมหานคร 10110');
        Setting::set('company_phone', '02-123-4567');
        Setting::set('show_product_images', '1');
        Setting::set('low_stock_threshold', '10');
        Setting::set('logo_path', null);

        // Note: first admin created by php artisan onedaypos:install
    }
}
