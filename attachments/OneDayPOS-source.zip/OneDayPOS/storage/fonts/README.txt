วางไฟล์ tahoma.ttf ที่นี่สำหรับฝังใน PDF
บน Windows คัดลอกจาก C:\Windows\Fonts\tahoma.ttf
ถ้าไม่มี ระบบจะใช้ฟอนต์สำรองและแจ้งเตือนในหน้าตั้งค่า
