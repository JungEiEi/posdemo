<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OneDayPOS</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script defer src="{{ asset('js/alpine.min.js') }}"></script>
    <style>
        :root {
            --brand: #790D16;
            --sand: #E5D3AF;
            --cream: #F5EFE1;
            --sky: #AEC4D4;
        }
        body { font-family: Tahoma, sans-serif; background: var(--cream); margin: 0; color: #333; }
        .sidebar { position: fixed; top: 0; left: -260px; width: 260px; height: 100%; background: #fff; box-shadow: 2px 0 8px rgba(0,0,0,.15); transition: left .25s; z-index: 1000; padding: 16px; }
        .sidebar.open { left: 0; }
        .overlay { position: fixed; inset: 0; background: rgba(0,0,0,.4); z-index: 999; display: none; }
        .overlay.show { display: block; }
        .topbar { background: var(--brand); color: white; padding: 10px 16px; display: flex; align-items: center; gap: 12px; }
        .btn { padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; font-family: inherit; }
        .btn-primary { background: var(--brand); color: white; }
        .btn-secondary { background: var(--sand); }
        .menu-item { display: block; padding: 10px 0; text-decoration: none; color: #333; border-bottom: 1px solid #eee; }
        .menu-item:hover, .menu-item.active { background: var(--sky); }
    </style>
</head>
<body>
    <div class="topbar">
        <button onclick="document.getElementById('sidebar').classList.toggle('open'); document.getElementById('overlay').classList.toggle('show');" class="btn" style="background:transparent; color:white; font-size:20px;">☰</button>
        <strong>OneDayPOS</strong>
        <span style="margin-left:auto;">{{ auth()->user()->name ?? '' }} ({{ auth()->user()->role ?? '' }})</span>
        <form method="POST" action="{{ route('logout') }}" style="display:inline;">
            @csrf
            <button type="submit" class="btn" style="background:transparent; color:white;">ออกจากระบบ</button>
        </form>
    </div>

    <div id="overlay" class="overlay" onclick="document.getElementById('sidebar').classList.remove('open'); this.classList.remove('show');"></div>
    <div id="sidebar" class="sidebar">
        <a href="{{ route('pos') }}" class="menu-item">POS</a>
        <a href="{{ route('reports') }}" class="menu-item">รายงานยอดขาย</a>
        <a href="{{ route('stock') }}" class="menu-item">สต๊อก</a>
        @if(auth()->user()?->isAdmin())
            <a href="{{ route('admin.settings') }}" class="menu-item">ระบบแอดมิน</a>
        @endif
        <div style="margin-top:20px; font-size:12px; color:#666;">
            เครื่อง: <span id="terminal-display">-</span>
        </div>
    </div>

    <div style="padding:16px;">
        @yield('content')
    </div>

    <script>
        // Terminal name from localStorage
        document.addEventListener('DOMContentLoaded', () => {
            const name = localStorage.getItem('onedaypos_terminal') || 'POS-1';
            const el = document.getElementById('terminal-display');
            if (el) el.textContent = name;
        });
    </script>
    @stack('scripts')
</body>
</html>
