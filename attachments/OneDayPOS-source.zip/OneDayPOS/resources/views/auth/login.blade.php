<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ — OneDayPOS</title>
    <style>
        body { font-family: Tahoma, sans-serif; background: #F5EFE1; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 32px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,.1); width: 320px; text-align: center; }
        input { width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; border: 1px solid #E5D3AF; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #790D16; color: white; border: none; border-radius: 4px; cursor: pointer; font-family: inherit; }
        .error { color: #790D16; font-size: 14px; }
    </style>
</head>
<body>
    <div class="box">
        @if($logo)
            <img src="{{ asset('storage/' . $logo) }}" alt="Logo" style="max-width:120px; margin-bottom:12px;">
        @else
            <h2 style="color:#790D16; margin:0 0 16px;">OneDayPOS</h2>
        @endif
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <input type="text" name="username" placeholder="ชื่อผู้ใช้" required autofocus>
            <input type="password" name="password" placeholder="รหัสผ่าน" required>
            @error('username')
                <div class="error">{{ $message }}</div>
            @enderror
            <button type="submit">เข้าสู่ระบบ</button>
        </form>
    </div>
</body>
</html>
