<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ใบเสร็จ {{ $order->receipt_no_display }}</title>
    <style>
        @page { size: 80mm auto; margin: 0; }
        body { font-family: Tahoma, sans-serif; font-size: 12px; width: 72mm; margin: 0 auto; padding: 4mm; }
        .center { text-align: center; }
        .right { text-align: right; }
        .bold { font-weight: bold; }
        table { width: 100%; border-collapse: collapse; }
        hr { border: none; border-top: 1px dashed #000; margin: 4px 0; }
        .void { color: #790D16; font-weight: bold; text-align: center; font-size: 14px; margin: 8px 0; }
    </style>
</head>
<body>
    <div class="center">
        <div class="bold">{{ $settings['company_name'] ?? 'บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด' }}</div>
        <div>{{ $settings['company_address'] ?? '88/9 ถนนสุขุมวิท ซอย 39 แขวงคลองตันเหนือ เขตวัฒนา กรุงเทพมหานคร 10110' }}</div>
        <div>โทร {{ $settings['company_phone'] ?? '02-123-4567' }}</div>
        {{-- ไม่มีเลขผู้เสียภาษี ตามที่กำหนด --}}
    </div>
    <hr>
    <div>เลขที่ / No. &nbsp; <strong>{{ $order->receipt_no_short }}</strong></div>
    <div>วันที่ / Date &nbsp; {{ $order->created_at->format('d/m/Y') }}</div>
    <hr>
    <table>
        <thead>
            <tr>
                <th style="text-align:left; width:10%">ลำดับ</th>
                <th style="text-align:left">รายการ</th>
                <th style="text-align:right">จำนวน</th>
                <th style="text-align:right">ราคา</th>
            </tr>
        </thead>
        <tbody>
            @foreach($order->items as $idx => $item)
            <tr>
                <td>{{ $idx + 1 }}</td>
                <td>{{ $item->product_name }}</td>
                <td class="right">{{ $item->qty }}</td>
                <td class="right">{{ number_format($item->line_total, 0) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <hr>
    <div class="right">รวม &nbsp; {{ number_format($order->total, 0) }}</div>
    @if($order->payment_method === 'cash')
        <div class="right">รับ &nbsp; {{ number_format($order->cash_received, 0) }}</div>
        <div class="right">ทอน &nbsp; {{ number_format($order->change_amount, 0) }}</div>
    @elseif($order->payment_method === 'transfer')
        <div class="right">โอนเงิน &nbsp; {{ number_format($order->total, 0) }}</div>
    @elseif($order->payment_method === 'credit')
        <div class="right">บัตรเครดิต &nbsp; {{ number_format($order->total, 0) }}</div>
    @endif
    @if($order->status === 'void')
        <div class="void">** ยกเลิก **</div>
        <div class="center">เหตุผล: {{ $order->void_reason }}</div>
    @endif
    <div class="center" style="margin-top:12px; font-size:10px;">ขอบคุณที่ใช้บริการ</div>
</body>
</html>
