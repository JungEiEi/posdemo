@extends('layouts.app')

@section('content')
<div x-data="posApp()" x-init="init()" style="display:flex; gap:16px; height: calc(100vh - 80px);">
    <!-- Products 80% -->
    <div style="flex:4; overflow:auto;">
        <div style="margin-bottom:12px; display:flex; gap:8px; flex-wrap:wrap;">
            <button class="btn btn-secondary" :class="selectedCategory === null ? 'btn-primary' : ''" @click="selectedCategory = null">รวมเมนูทั้งหมด</button>
            <template x-for="cat in categories" :key="cat.id">
                <button class="btn btn-secondary" :class="selectedCategory === cat.id ? 'btn-primary' : ''" @click="selectedCategory = cat.id" x-text="cat.name"></button>
            </template>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap:12px;">
            <template x-for="p in filteredProducts" :key="p.id">
                <div class="product-card" @click="addToCart(p)" 
                     :style="p.stock_qty <= 0 && p.track_stock ? 'opacity:0.5; pointer-events:none;' : ''"
                     style="background:white; border:1px solid var(--sand); border-radius:8px; padding:8px; text-align:center; cursor:pointer;">
                    <template x-if="showImages && p.image_path">
                        <img :src="'/storage/' + p.image_path" style="width:100%; height:80px; object-fit:cover; border-radius:4px;">
                    </template>
                    <div x-text="p.name" style="font-weight:normal; margin:4px 0;"></div>
                    <div style="color:var(--brand);">฿<span x-text="p.price"></span></div>
                    <template x-if="p.track_stock && p.stock_qty <= 0">
                        <div style="color:var(--brand); font-size:12px;">หมด</div>
                    </template>
                    <template x-if="p.track_stock && p.stock_qty > 0 && p.stock_qty < lowThreshold">
                        <div style="color:var(--brand); font-size:11px;">เหลือ <span x-text="p.stock_qty"></span></div>
                    </template>
                </div>
            </template>
        </div>
    </div>

    <!-- Cart 20% -->
    <div style="flex:1; background:white; border:1px solid var(--sand); border-radius:8px; padding:12px; display:flex; flex-direction:column;">
        <h3 style="margin:0 0 8px; color:var(--brand);">ตะกร้า</h3>
        <div style="flex:1; overflow:auto;">
            <template x-for="(item, idx) in cart" :key="idx">
                <div style="display:flex; justify-content:space-between; align-items:center; padding:4px 0; border-bottom:1px solid #eee;">
                    <div>
                        <div x-text="item.name"></div>
                        <small>x<span x-text="item.qty"></span></small>
                    </div>
                    <div>
                        <button @click="changeQty(idx, -1)">−</button>
                        <span x-text="item.line_total"></span>
                        <button @click="changeQty(idx, 1)">+</button>
                    </div>
                </div>
            </template>
            <div x-show="cart.length === 0" style="color:#999; text-align:center; padding:20px;">ยังไม่มีรายการ</div>
        </div>
        <div style="border-top:1px solid var(--sand); padding-top:8px;">
            <div style="display:flex; justify-content:space-between; font-size:18px;">
                <span>รวม</span>
                <span>฿<span x-text="total"></span></span>
            </div>
            <div style="display:flex; gap:8px; margin-top:8px;">
                <button class="btn btn-secondary" @click="cart = []" style="flex:1;">ล้าง</button>
                <button class="btn btn-primary" @click="openPayment()" :disabled="cart.length === 0" style="flex:2;">ชำระเงิน</button>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal (simplified) -->
<div x-show="showPayment" style="position:fixed; inset:0; background:rgba(0,0,0,.5); display:flex; align-items:center; justify-content:center; z-index:2000;" @click.self="showPayment = false">
    <div style="background:white; padding:20px; border-radius:8px; width:320px;">
        <h3>ชำระเงิน</h3>
        <div style="margin:12px 0;">
            <label><input type="radio" x-model="paymentMethod" value="cash"> เงินสด</label>
            <label><input type="radio" x-model="paymentMethod" value="transfer"> โอนเงิน</label>
            <label><input type="radio" x-model="paymentMethod" value="credit"> บัตรเครดิต</label>
        </div>
        <template x-if="paymentMethod === 'cash'">
            <div>
                <div>ต้องชำระ: ฿<span x-text="total"></span></div>
                <input type="number" x-model.number="cashReceived" placeholder="เงินที่ได้รับ" style="width:100%; padding:8px; margin:8px 0;">
                <div>ทอน: ฿<span x-text="Math.max(0, cashReceived - total)"></span></div>
            </div>
        </template>
        <button class="btn btn-primary" style="width:100%; margin-top:12px;" @click="checkout()" :disabled="paymentMethod === 'cash' && cashReceived < total">ยืนยัน</button>
        <button class="btn" style="width:100%; margin-top:4px;" @click="showPayment = false">ยกเลิก</button>
    </div>
</div>

@push('scripts')
<script>
function posApp() {
    return {
        categories: @json($categories),
        products: @json($products),
        showImages: @json($showImages),
        lowThreshold: {{ $lowStockThreshold }},
        selectedCategory: null,
        cart: [],
        showPayment: false,
        paymentMethod: 'cash',
        cashReceived: 0,
        clientUuid: crypto.randomUUID(),
        get filteredProducts() {
            if (this.selectedCategory === null) return this.products;
            return this.products.filter(p => p.category_id === this.selectedCategory);
        },
        get total() {
            return this.cart.reduce((s, i) => s + i.line_total, 0);
        },
        addToCart(p) {
            if (p.track_stock && p.stock_qty <= 0) return;
            const exist = this.cart.find(i => i.product_id === p.id);
            if (exist) {
                if (p.track_stock && exist.qty >= p.stock_qty) return;
                exist.qty++;
                exist.line_total = exist.qty * p.price;
            } else {
                this.cart.push({
                    product_id: p.id,
                    name: p.name,
                    price: parseFloat(p.price),
                    qty: 1,
                    line_total: parseFloat(p.price),
                    track_stock: p.track_stock,
                    stock_qty: p.stock_qty
                });
            }
        },
        changeQty(idx, delta) {
            const item = this.cart[idx];
            const newQty = item.qty + delta;
            if (newQty <= 0) {
                this.cart.splice(idx, 1);
                return;
            }
            if (item.track_stock && newQty > item.stock_qty) return;
            item.qty = newQty;
            item.line_total = newQty * item.price;
        },
        openPayment() {
            this.cashReceived = this.total;
            this.showPayment = true;
        },
        async checkout() {
            const terminal = localStorage.getItem('onedaypos_terminal') || 'POS-1';
            const payload = {
                client_uuid: this.clientUuid,
                items: this.cart.map(i => ({ product_id: i.product_id, qty: i.qty })),
                payment_method: this.paymentMethod,
                cash_received: this.paymentMethod === 'cash' ? this.cashReceived : null,
                terminal_name: terminal,
                _token: '{{ csrf_token() }}'
            };
            try {
                const res = await fetch('{{ route('orders.store') }}', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (data.success) {
                    // Open receipt
                    window.open(data.print_url, '_blank');
                    // Reset
                    this.cart = [];
                    this.showPayment = false;
                    this.clientUuid = crypto.randomUUID();
                    alert('ขายสำเร็จ เลขที่ ' + data.receipt_no);
                    // Refresh stock later via polling
                } else {
                    alert(data.message || 'เกิดข้อผิดพลาด');
                }
            } catch (e) {
                alert('ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์');
            }
        },
        init() {
            // Polling stock every 10s
            setInterval(async () => {
                try {
                    const res = await fetch('{{ route('pos.stock-status') }}');
                    const stocks = await res.json();
                    this.products.forEach(p => {
                        if (stocks[p.id] !== undefined) p.stock_qty = stocks[p.id];
                    });
                } catch(e) {}
            }, 10000);
        }
    }
}
</script>
@endpush
@endsection
