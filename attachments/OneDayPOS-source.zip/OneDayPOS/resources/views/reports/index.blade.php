@extends('layouts.app')

@section('content')
<h2>รายงานยอดขาย</h2>
<p>ส่วนนี้เป็นร่าง — ในเวอร์ชันเต็มจะมีตารางรายบิล, กรอง, Excel/PDF, ประวัติยกเลิกบิล และฟอร์มนำส่งเงินสด</p>
<div class="alert">ดูเอกสาร OneDayPOS.md ข้อ 6.2 สำหรับรายละเอียดเต็ม</div>
@endsection
