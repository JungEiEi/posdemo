@extends('layouts.app')

@section('content')
<h2>สต๊อก</h2>
<p>ส่วนนี้เป็นร่าง — ในเวอร์ชันเต็มจะมีรับเข้าสต๊อก, คงเหลือรายวัน, แผงสินค้าใกล้หมด</p>
<div class="alert">ดูเอกสาร OneDayPOS.md ข้อ 6.3 สำหรับรายละเอียดเต็ม</div>
@endsection
