@extends('layouts.app')

@section('content')
<h2>ตั้งค่าระบบ</h2>
<form method="POST" action="#" style="max-width:480px;">
    @csrf
    <label>ชื่อบริษัท (แสดงในใบเสร็จ)</label><br>
    <input type="text" name="company_name" value="บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด" style="width:100%; padding:8px; margin:4px 0 12px;"><br>
    <label>ที่อยู่</label><br>
    <textarea name="company_address" style="width:100%; padding:8px; margin:4px 0 12px;" rows="3">88/9 ถนนสุขุมวิท ซอย 39 แขวงคลองตันเหนือ เขตวัฒนา กรุงเทพมหานคร 10110</textarea><br>
    <label>โทรศัพท์</label><br>
    <input type="text" name="company_phone" value="02-123-4567" style="width:100%; padding:8px; margin:4px 0 12px;"><br>
    <label>เกณฑ์สต๊อกใกล้หมด</label><br>
    <input type="number" name="low_stock_threshold" value="10" style="width:100%; padding:8px; margin:4px 0 12px;"><br>
    <label><input type="checkbox" name="show_product_images" checked> แสดงรูปสินค้า</label><br><br>
    <button class="btn btn-primary" type="submit">บันทึก</button>
</form>
<p style="margin-top:16px; color:#666;">ข้อมูลบริษัทเริ่มต้นเป็นบริษัทจำลองตามที่กำหนด</p>
@endsection
