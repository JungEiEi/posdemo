<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;

class OneDayPosInstall extends Command
{
    protected $signature = 'onedaypos:install {--username=admin} {--password=}';
    protected $description = 'ติดตั้งระบบ OneDayPOS (สร้างตาราง + ผู้ดูแลระบบคนแรก + ข้อมูลเริ่มต้น)';

    public function handle()
    {
        $this->info('กำลังสร้างตาราง...');
        Artisan::call('migrate', ['--force' => true]);
        $this->info(Artisan::output());

        $this->info('สร้าง storage link...');
        Artisan::call('storage:link');

        $username = $this->option('username');
        $password = $this->option('password') ?: $this->secret('รหัสผ่านผู้ดูแลระบบคนแรก');

        if (!User::where('username', $username)->exists()) {
            User::create([
                'username' => $username,
                'name' => 'ผู้ดูแลระบบ',
                'password' => Hash::make($password),
                'role' => 'admin',
                'is_active' => true,
            ]);
            $this->info("สร้างผู้ดูแลระบบ: {$username}");
        } else {
            $this->warn("ผู้ใช้ {$username} มีอยู่แล้ว");
        }

        $this->info('รัน seeder...');
        Artisan::call('db:seed', ['--force' => true]);

        $this->info('ติดตั้งเสร็จสิ้น!');
        $this->info('ข้อมูลบริษัทเริ่มต้นในใบเสร็จ: บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด (ปรับได้ในตั้งค่า)');
    }
}
