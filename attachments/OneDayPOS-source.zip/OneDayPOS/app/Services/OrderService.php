<?php

namespace App\Services;

use App\Models\ActivityLog;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\StockMovement;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrderService
{
    public function createOrder(array $cartItems, string $paymentMethod, ?float $cashReceived, string $clientUuid, User $user, ?string $terminalName = null, string $ip = null): Order
    {
        return DB::transaction(function () use ($cartItems, $paymentMethod, $cashReceived, $clientUuid, $user, $terminalName, $ip) {
            // Prevent duplicate by client_uuid
            $existing = Order::where('client_uuid', $clientUuid)->first();
            if ($existing) {
                return $existing;
            }

            $year = (int) now()->format('Y');
            $beYear = $year + 543;
            $shortYear = $beYear % 100; // e.g. 69 for 2569

            // Lock counter
            $counter = DB::table('receipt_counters')
                ->where('receipt_year', $year)
                ->lockForUpdate()
                ->first();

            if (!$counter) {
                DB::table('receipt_counters')->insert([
                    'receipt_year' => $year,
                    'seq_no' => 0,
                ]);
                $seq = 1;
            } else {
                $seq = $counter->seq_no + 1;
            }

            DB::table('receipt_counters')
                ->where('receipt_year', $year)
                ->update(['seq_no' => $seq]);

            $receiptShort = sprintf('MP%02d%04d', $shortYear, $seq);
            $receiptLong = sprintf('MP%d%04d', $year, $seq);

            $total = 0;
            $itemsData = [];

            // Sort by product_id to reduce deadlock
            usort($cartItems, fn($a, $b) => ($a['product_id'] ?? 0) <=> ($b['product_id'] ?? 0));

            foreach ($cartItems as $item) {
                $product = Product::lockForUpdate()->find($item['product_id']);
                if (!$product || !$product->is_active) {
                    throw new \Exception('สินค้าไม่พร้อมขาย');
                }

                $qty = (int) $item['qty'];
                $lineTotal = $product->price * $qty;
                $total += $lineTotal;

                if ($product->track_stock) {
                    $updated = Product::where('id', $product->id)
                        ->where('stock_qty', '>=', $qty)
                        ->decrement('stock_qty', $qty);

                    if ($updated === 0) {
                        throw new \Exception("{$product->name} เหลือ {$product->stock_qty} ชิ้น แต่ต้องการ {$qty} ชิ้น");
                    }

                    $newStock = $product->stock_qty - $qty;
                    StockMovement::create([
                        'product_id' => $product->id,
                        'type' => 'sale',
                        'qty' => -$qty,
                        'stock_after' => $newStock,
                        'user_id' => $user->id,
                        'note' => 'ขาย',
                        'movement_date' => now()->toDateString(),
                    ]);
                }

                $itemsData[] = [
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'unit_price' => $product->price,
                    'qty' => $qty,
                    'line_total' => $lineTotal,
                    'track_stock' => $product->track_stock,
                ];
            }

            $change = null;
            if ($paymentMethod === 'cash') {
                if ($cashReceived < $total) {
                    throw new \Exception('เงินที่รับไม่พอ');
                }
                $change = $cashReceived - $total;
            }

            $order = Order::create([
                'client_uuid' => $clientUuid,
                'receipt_year' => $year,
                'seq_no' => $seq,
                'receipt_no_short' => $receiptShort,
                'receipt_no_long' => $receiptLong,
                'user_id' => $user->id,
                'terminal_name' => $terminalName,
                'payment_method' => $paymentMethod,
                'total' => $total,
                'cash_received' => $cashReceived,
                'change_amount' => $change,
                'status' => 'normal',
            ]);

            foreach ($itemsData as $data) {
                $data['order_id'] = $order->id;
                OrderItem::create($data);
                // update stock movement with order_id if needed
                if ($data['track_stock']) {
                    StockMovement::where('product_id', $data['product_id'])
                        ->whereNull('order_id')
                        ->where('type', 'sale')
                        ->latest()
                        ->limit(1)
                        ->update(['order_id' => $order->id]);
                }
            }

            ActivityLog::create([
                'action_code' => 'sale',
                'message_th' => "ผู้ขาย {$user->name} ออกบิล {$receiptShort} ยอด {$total} บาท ชำระด้วย" . $this->paymentLabel($paymentMethod) . " (เครื่อง {$terminalName})",
                'level' => 'info',
                'user_id' => $user->id,
                'terminal_name' => $terminalName,
                'ip_address' => $ip,
            ]);

            return $order->load('items');
        }, 3); // retry 3 times
    }

    public function voidOrder(Order $order, string $reason, User $user, ?string $terminalName = null, string $ip = null): void
    {
        DB::transaction(function () use ($order, $reason, $user, $terminalName, $ip) {
            $order = Order::lockForUpdate()->find($order->id);
            if ($order->status === 'void') {
                throw new \Exception('บิลนี้ถูกยกเลิกไปแล้ว');
            }

            // Permission: seller only own same day, admin any
            if (!$user->isAdmin()) {
                if ($order->user_id !== $user->id || $order->created_at->toDateString() !== now()->toDateString()) {
                    throw new \Exception('ไม่มีสิทธิ์ยกเลิกบิลนี้');
                }
            }

            $order->update([
                'status' => 'void',
                'voided_by' => $user->id,
                'voided_at' => now(),
                'void_reason' => $reason,
            ]);

            // Return stock
            foreach ($order->items as $item) {
                if ($item->track_stock && $item->product_id) {
                    $product = Product::lockForUpdate()->find($item->product_id);
                    if ($product) {
                        $product->increment('stock_qty', $item->qty);
                        StockMovement::create([
                            'product_id' => $product->id,
                            'type' => 'void',
                            'qty' => $item->qty,
                            'stock_after' => $product->stock_qty,
                            'order_id' => $order->id,
                            'user_id' => $user->id,
                            'note' => 'คืนจากยกเลิกบิล',
                            'movement_date' => now()->toDateString(),
                        ]);
                    }
                }
            }

            ActivityLog::create([
                'action_code' => 'void',
                'message_th' => "ผู้ขาย {$user->name} ยกเลิกบิล {$order->receipt_no_short} ยอด {$order->total} บาท เหตุผล: {$reason} (เครื่อง {$terminalName})",
                'level' => 'info',
                'user_id' => $user->id,
                'terminal_name' => $terminalName,
                'ip_address' => $ip,
            ]);
        });
    }

    private function paymentLabel(string $method): string
    {
        return match ($method) {
            'cash' => 'เงินสด',
            'transfer' => 'โอนเงิน',
            'credit' => 'บัตรเครดิต',
            default => $method,
        };
    }
}
