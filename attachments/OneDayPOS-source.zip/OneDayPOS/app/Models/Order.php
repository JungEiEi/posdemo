<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    protected $fillable = [
        'client_uuid', 'receipt_year', 'seq_no', 'receipt_no_short', 'receipt_no_long',
        'user_id', 'terminal_name', 'payment_method', 'total', 'cash_received',
        'change_amount', 'status', 'voided_by', 'voided_at', 'void_reason',
    ];

    protected $casts = [
        'total' => 'decimal:2',
        'cash_received' => 'decimal:2',
        'change_amount' => 'decimal:2',
        'voided_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function voidedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'voided_by');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function getReceiptNoDisplayAttribute(): string
    {
        return $this->receipt_no_short;
    }
}
