<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $fillable = [
        'category_id', 'name', 'sku', 'price', 'track_stock',
        'stock_qty', 'image_path', 'is_active',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'track_stock' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function movements(): HasMany
    {
        return $this->hasMany(StockMovement::class);
    }

    public function isLowStock(int $threshold = 10): bool
    {
        return $this->track_stock && $this->stock_qty > 0 && $this->stock_qty < $threshold;
    }

    public function isOutOfStock(): bool
    {
        return $this->track_stock && $this->stock_qty <= 0;
    }
}
