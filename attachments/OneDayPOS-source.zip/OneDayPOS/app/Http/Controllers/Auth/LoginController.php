<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        $logo = Setting::get('logo_path');
        return view('auth.login', compact('logo'));
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        if (Auth::attempt(['username' => $credentials['username'], 'password' => $credentials['password'], 'is_active' => true])) {
            $request->session()->regenerate();

            ActivityLog::create([
                'action_code' => 'login_success',
                'message_th' => 'ผู้ใช้ ' . Auth::user()->username . ' (' . Auth::user()->role . ') เข้าสู่ระบบ จาก ' . $request->ip(),
                'level' => 'info',
                'user_id' => Auth::id(),
                'ip_address' => $request->ip(),
            ]);

            return redirect()->intended('/pos');
        }

        ActivityLog::create([
            'action_code' => 'login_failed',
            'message_th' => 'เข้าสู่ระบบไม่สำเร็จ ชื่อผู้ใช้ ' . $credentials['username'] . ' รหัสผ่านไม่ถูกต้อง',
            'level' => 'warning',
            'ip_address' => $request->ip(),
        ]);

        return back()->withErrors(['username' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง หรือบัญชีถูกปิดใช้งาน']);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
