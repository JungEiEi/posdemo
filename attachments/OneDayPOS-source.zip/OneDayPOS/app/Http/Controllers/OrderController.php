<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function __construct(private OrderService $orderService) {}

    public function store(Request $request)
    {
        $request->validate([
            'client_uuid' => 'required|uuid',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.qty' => 'required|integer|min:1',
            'payment_method' => 'required|in:cash,transfer,credit',
            'cash_received' => 'nullable|numeric|min:0',
            'terminal_name' => 'nullable|string|max:50',
        ]);

        try {
            $order = $this->orderService->createOrder(
                $request->items,
                $request->payment_method,
                $request->cash_received,
                $request->client_uuid,
                Auth::user(),
                $request->terminal_name,
                $request->ip()
            );

            return response()->json([
                'success' => true,
                'order_id' => $order->id,
                'receipt_no' => $order->receipt_no_short,
                'total' => $order->total,
                'print_url' => route('orders.receipt', $order),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function receipt(Order $order)
    {
        $order->load('items');
        $settings = [
            'company_name' => \App\Models\Setting::get('company_name', 'บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด'),
            'company_address' => \App\Models\Setting::get('company_address', '88/9 ถนนสุขุมวิท ซอย 39 แขวงคลองตันเหนือ เขตวัฒนา กรุงเทพมหานคร 10110'),
            'company_phone' => \App\Models\Setting::get('company_phone', '02-123-4567'),
        ];

        return view('receipts.receipt', compact('order', 'settings'));
    }

    public function void(Request $request, Order $order)
    {
        $request->validate([
            'reason' => 'required|string|max:255',
            'terminal_name' => 'nullable|string|max:50',
        ]);

        try {
            $this->orderService->voidOrder(
                $order,
                $request->reason,
                Auth::user(),
                $request->terminal_name,
                $request->ip()
            );

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    public function todayOrders()
    {
        $query = Order::with('user')
            ->whereDate('created_at', today())
            ->orderByDesc('id');

        if (!Auth::user()->isAdmin()) {
            $query->where('user_id', Auth::id());
        }

        return response()->json($query->get());
    }
}
