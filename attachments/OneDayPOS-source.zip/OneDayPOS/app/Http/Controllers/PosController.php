<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\Request;

class PosController extends Controller
{
    public function index()
    {
        $categories = Category::where('is_active', true)->orderBy('sort_order')->get();
        $products = Product::with('category')
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        $showImages = Setting::get('show_product_images', '1') === '1';
        $lowStockThreshold = (int) Setting::get('low_stock_threshold', 10);

        return view('pos.index', compact('categories', 'products', 'showImages', 'lowStockThreshold'));
    }

    public function stockStatus()
    {
        $stocks = Product::where('is_active', true)
            ->where('track_stock', true)
            ->pluck('stock_qty', 'id');

        return response()->json($stocks);
    }
}
