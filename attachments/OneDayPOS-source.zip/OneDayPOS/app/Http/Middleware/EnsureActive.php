<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureActive
{
    public function handle(Request $request, Closure $next)
    {
        if (auth()->check() && !auth()->user()->is_active) {
            auth()->logout();
            return redirect('/login')->withErrors(['username' => 'บัญชีถูกปิดใช้งาน']);
        }
        return $next($request);
    }
}
