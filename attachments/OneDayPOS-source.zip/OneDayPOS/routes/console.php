<?php

use Illuminate\Support\Facades\Schedule;

// Backup schedule example — enable in settings
// Schedule::command('onedaypos:backup')->dailyAt('02:00');
