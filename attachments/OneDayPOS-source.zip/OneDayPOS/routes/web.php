<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PosController;
use Illuminate\Support\Facades\Route;

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware(['auth', 'active'])->group(function () {
    Route::get('/pos', [PosController::class, 'index'])->name('pos');
    Route::get('/pos/stock-status', [PosController::class, 'stockStatus'])->name('pos.stock-status');

    Route::post('/pos/orders', [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}/receipt', [OrderController::class, 'receipt'])->name('orders.receipt');
    Route::post('/orders/{order}/void', [OrderController::class, 'void'])->name('orders.void');
    Route::get('/pos/orders/today', [OrderController::class, 'todayOrders'])->name('orders.today');

    // Reports, Stock, Admin routes would go here (abbreviated for this draft)
    Route::view('/reports', 'reports.index')->name('reports');
    Route::view('/stock', 'stock.index')->name('stock');
    Route::prefix('admin')->middleware('role:admin')->group(function () {
        Route::view('/settings', 'admin.settings')->name('admin.settings');
        // other admin routes
    });
});

Route::redirect('/', '/pos');
