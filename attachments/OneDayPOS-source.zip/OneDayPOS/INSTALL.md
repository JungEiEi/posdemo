# OneDayPOS — คู่มือติดตั้ง (Laravel + MySQL)

โฟลเดอร์นี้คือ **ชุดไฟล์โปรแกรม** (app, routes, views, migrations, tests ฯลฯ) สำหรับนำไปวางทับโปรเจกต์ Laravel ที่สร้างใหม่ ไม่ได้รวมโฟลเดอร์ `vendor/` ของ Laravel
ทำตามขั้นตอนด้านล่างบนเครื่องที่จะเป็น **เซิร์ฟเวอร์กลาง** (เครื่องขายทุกเครื่องเปิดผ่านเบราว์เซอร์)

> สถานะ: เขียนตามเอกสาร OneDayPOS.md แล้ว แต่ **ยังไม่เคยรันบนเครื่องจริง**
> หลังติดตั้ง ให้รัน `php artisan test` ก่อนใช้งานจริง และดู "รายการตรวจรับ" ท้ายเอกสาร
>
> **ข้อมูลบริษัทในใบเสร็จ:** ใช้บริษัทจำลอง "บริษัท วันเดย์ คาเฟ่ แอนด์ เบเกอรี่ จำกัด" ที่อยู่และเบอร์โทรจำลอง (ปรับได้ในตั้งค่า)

## 1. สิ่งที่ต้องมี

- PHP 8.2 ขึ้นไป พร้อมส่วนขยาย: `mbstring`, `pdo_mysql`, `gd` (รองรับ webp), `zip`, `fileinfo`, `xml`, `curl`, `intl`
- MySQL 8 (หรือ MariaDB 10.6+) และมีโปรแกรม `mysqldump` / `mysql` สำหรับ Backup/Restore
- Composer 2
- ไม่ต้องใช้ Node.js (CSS เขียนมือ และแนบ Alpine.js ในโฟลเดอร์ `public/js`)

แนะนำ Windows: **Laragon** หรือ XAMPP

## 2. สร้างโปรเจกต์ Laravel แล้ววางไฟล์ทับ

```
composer create-project laravel/laravel OneDayPOS
```

- ใช้ Laravel เวอร์ชันล่าสุดที่ Composer ติดตั้งให้
- คัดลอก **เนื้อหาทั้งหมด** จากโฟลเดอร์นี้ทับในโฟลเดอร์ `OneDayPOS` (เลือก "แทนที่ไฟล์เดิม")

## 3. ติดตั้งแพ็กเกจเพิ่ม

```
cd OneDayPOS
composer require mpdf/mpdf phpoffice/phpspreadsheet
```

(ถ้าจะ Backup ขึ้น Cloud แบบ S3: `composer require league/flysystem-aws-s3-v3 "^3.0"`)

## 4. ตั้งค่าฐานข้อมูลและ .env

สร้างฐานข้อมูล:

```sql
CREATE DATABASE onedaypos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'onedaypos'@'localhost' IDENTIFIED BY 'รหัสผ่านของคุณ';
GRANT ALL PRIVILEGES ON onedaypos.* TO 'onedaypos'@'localhost';
```

เปิดไฟล์ `.env` แล้วปรับค่า `APP_TIMEZONE=Asia/Bangkok`, ข้อมูล `DB_*`

## 5. ติดตั้งระบบ

```
php artisan onedaypos:install
```

คำสั่งนี้จะสร้างตารางทั้งหมด, `storage link`, สร้างผู้ดูแลระบบคนแรก และหมวดหมู่ตัวอย่าง

## 6. ฟอนต์ Tahoma สำหรับ PDF

คัดลอก `C:\Windows\Fonts\tahoma.ttf` ไปไว้ที่ `storage/fonts/tahoma.ttf`

## 7. เปิดใช้งาน

```
php artisan serve --host=0.0.0.0 --port=8000
```

เครื่องขายอื่นเปิด `http://<IP เซิร์ฟเวอร์>:8000`

## 8. ตั้งค่าเครื่องขายแต่ละเครื่อง

1. ติดตั้งไดรเวอร์เครื่องพิมพ์ 80 mm → ตั้งเป็นเครื่องพิมพ์เริ่มต้น
2. สร้างทางลัด Chrome/Edge ด้วย `--kiosk-printing`
3. ในหน้า POS กด ⚙ → ตั้งชื่อเครื่อง และเลือกโหมดพิมพ์

## 9. Backup อัตโนมัติ

เปิดในเมนูฐานข้อมูล แล้วตั้ง Task Scheduler / crontab ให้เรียก `php artisan schedule:run` ทุกนาที

## 10. ทดสอบ

```
php artisan test
```

## รายการตรวจรับด้วยมือ

- [ ] เปิด 2 เครื่อง ขายเมนูชิ้นสุดท้ายพร้อมกัน → สำเร็จเครื่องเดียว
- [ ] พิมพ์ใบเสร็จจริงบนเครื่อง USB 80 mm (ภาษาไทย ฟอนต์ ความกว้าง)
- [ ] ยกเลิกบิล → สต๊อกคืน → ปรากฏในประวัติยกเลิก และไม่นับในรายงาน
- [ ] ข้อมูลบริษัทในใบเสร็จเป็นบริษัทจำลองที่กำหนด

## การอัปเดตระบบในอนาคต

คัดลอกไฟล์ที่เปลี่ยนทับ → `composer install --no-dev` → `php artisan migrate --force` → `php artisan optimize:clear` และบันทึกลง `progress.md`
